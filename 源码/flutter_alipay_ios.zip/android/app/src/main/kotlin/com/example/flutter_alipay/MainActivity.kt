package com.example.flutter_alipay

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
